# Usage
my_fw = Firewall(base_url=192.168.1.1, api_key='123245')